import router from '@system.router'
import napitest from '@ohos.napitest';

export default {
    data: {
        title: ""
    },
    onInit() {
        this.title = this.$t('strings.world');
    },
    onclick: function () {
        router.replace({
            uri: "pages/second/second"
        })
    },
    isScreenOn: function () {
        napitest.isScreenOn()
            .then(screenOn => {
                console.info('power_is_screen_on_promise_test screenOn is ' + screenOn);
            })
            .catch(error => {
                console.log('power_is_screen_on_promise_test error: ' + error);
            })

    }
}



